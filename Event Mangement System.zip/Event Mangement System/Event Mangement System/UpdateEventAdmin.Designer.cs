﻿namespace Event_Mangement_System
{
    partial class UpdateEventAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            detail = new TextBox();
            invoice = new TextBox();
            employee = new TextBox();
            baloon = new TextBox();
            company = new TextBox();
            place = new TextBox();
            timee = new DateTimePicker();
            date = new DateTimePicker();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label1 = new Label();
            label2 = new Label();
            labelid = new Label();
            id = new TextBox();
            label9 = new Label();
            email = new TextBox();
            linkLabel1 = new LinkLabel();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.None;
            button1.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(187, 548);
            button1.Name = "button1";
            button1.Size = new Size(574, 58);
            button1.TabIndex = 42;
            button1.Text = "Update Event";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // detail
            // 
            detail.Anchor = AnchorStyles.None;
            detail.Location = new Point(374, 481);
            detail.Multiline = true;
            detail.Name = "detail";
            detail.Size = new Size(387, 49);
            detail.TabIndex = 41;
            // 
            // invoice
            // 
            invoice.Anchor = AnchorStyles.None;
            invoice.Location = new Point(374, 426);
            invoice.Name = "invoice";
            invoice.Size = new Size(387, 31);
            invoice.TabIndex = 40;
            // 
            // employee
            // 
            employee.Anchor = AnchorStyles.None;
            employee.Location = new Point(374, 375);
            employee.Name = "employee";
            employee.Size = new Size(387, 31);
            employee.TabIndex = 39;
            // 
            // baloon
            // 
            baloon.Anchor = AnchorStyles.None;
            baloon.Location = new Point(374, 321);
            baloon.Name = "baloon";
            baloon.Size = new Size(387, 31);
            baloon.TabIndex = 38;
            // 
            // company
            // 
            company.Anchor = AnchorStyles.None;
            company.Location = new Point(374, 271);
            company.Name = "company";
            company.Size = new Size(387, 31);
            company.TabIndex = 37;
            // 
            // place
            // 
            place.Anchor = AnchorStyles.None;
            place.Location = new Point(374, 223);
            place.Name = "place";
            place.Size = new Size(387, 31);
            place.TabIndex = 36;
            // 
            // timee
            // 
            timee.Anchor = AnchorStyles.None;
            timee.Format = DateTimePickerFormat.Time;
            timee.Location = new Point(541, 172);
            timee.Name = "timee";
            timee.ShowUpDown = true;
            timee.Size = new Size(217, 31);
            timee.TabIndex = 35;
            // 
            // date
            // 
            date.Anchor = AnchorStyles.None;
            date.Format = DateTimePickerFormat.Short;
            date.Location = new Point(375, 172);
            date.Name = "date";
            date.Size = new Size(222, 31);
            date.TabIndex = 34;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(184, 480);
            label8.Name = "label8";
            label8.Size = new Size(96, 30);
            label8.TabIndex = 32;
            label8.Text = "Details :";
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(184, 427);
            label7.Name = "label7";
            label7.Size = new Size(99, 30);
            label7.TabIndex = 31;
            label7.Text = "Invoice :";
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(184, 376);
            label6.Name = "label6";
            label6.Size = new Size(136, 30);
            label6.TabIndex = 30;
            label6.Text = "Employees :";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(184, 322);
            label5.Name = "label5";
            label5.Size = new Size(187, 30);
            label5.TabIndex = 29;
            label5.Text = "Baloon Quantity:";
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(184, 272);
            label4.Name = "label4";
            label4.Size = new Size(187, 30);
            label4.TabIndex = 28;
            label4.Text = "Event Company :";
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(184, 224);
            label3.Name = "label3";
            label3.Size = new Size(144, 30);
            label3.TabIndex = 27;
            label3.Text = "Event place :";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(184, 172);
            label1.Name = "label1";
            label1.Size = new Size(147, 30);
            label1.TabIndex = 33;
            label1.Text = "Date / Time :";
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Elephant", 18F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            label2.Location = new Point(271, 19);
            label2.Name = "label2";
            label2.Size = new Size(490, 46);
            label2.TabIndex = 26;
            label2.Text = "Update Event (ADMIN) ";
            // 
            // labelid
            // 
            labelid.Anchor = AnchorStyles.None;
            labelid.AutoSize = true;
            labelid.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelid.Location = new Point(181, 125);
            labelid.Name = "labelid";
            labelid.Size = new Size(48, 30);
            labelid.TabIndex = 31;
            labelid.Text = "ID :";
            // 
            // id
            // 
            id.Anchor = AnchorStyles.None;
            id.Location = new Point(371, 124);
            id.Name = "id";
            id.Size = new Size(387, 31);
            id.TabIndex = 40;
            // 
            // label9
            // 
            label9.Anchor = AnchorStyles.None;
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(181, 78);
            label9.Name = "label9";
            label9.Size = new Size(81, 30);
            label9.TabIndex = 31;
            label9.Text = "Email :";
            // 
            // email
            // 
            email.Anchor = AnchorStyles.None;
            email.Location = new Point(371, 77);
            email.Name = "email";
            email.Size = new Size(387, 31);
            email.TabIndex = 40;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(193, 609);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(48, 25);
            linkLabel1.TabIndex = 43;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Back";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // UpdateEventAdmin
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(945, 652);
            Controls.Add(linkLabel1);
            Controls.Add(button1);
            Controls.Add(detail);
            Controls.Add(email);
            Controls.Add(id);
            Controls.Add(invoice);
            Controls.Add(employee);
            Controls.Add(baloon);
            Controls.Add(company);
            Controls.Add(place);
            Controls.Add(timee);
            Controls.Add(label9);
            Controls.Add(date);
            Controls.Add(labelid);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Name = "UpdateEventAdmin";
            Text = "UpdateEventAdmin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox detail;
        private TextBox invoice;
        private TextBox employee;
        private TextBox baloon;
        private TextBox company;
        private TextBox place;
        private DateTimePicker timee;
        private DateTimePicker date;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label1;
        private Label label2;
        private Label labelid;
        private TextBox id;
        private Label label9;
        private TextBox email;
        private LinkLabel linkLabel1;
    }
}